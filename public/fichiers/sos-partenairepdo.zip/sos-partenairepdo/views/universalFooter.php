  		<div class="push">
  	</div>
			<footer>
					<div class="row-fluid">
						<div class="col-xs-12 col-sm-6">
							<ul><h4 class="white">Plan du Site</h4>
								<a class="grey" href="partenaires.php"><li>Partenaires disponibles</li></a>
								<a class="grey" href="mesSports.php"><li>Mes sports</li></a>
								<a class="grey" href="formulairesMonCompte.php"><li>Mon compte</li></a>
							</ul>
						</div>
						<div class="col-xs-12 col-sm-6">
							<ul><h4 class="white">Conditions</h4>
								<a class="grey" href="ml.php"><li>Mentions légales</li></a>
								<a class="grey" href="cgu.php"><li>Conditions Génerales d'Utilisation</li></a>
							</ul>
						</div>
					</div>
			</footer>
		</div>
	</body>
	<script>
		$('.menuSelect2').select2();
	</script>
</html>