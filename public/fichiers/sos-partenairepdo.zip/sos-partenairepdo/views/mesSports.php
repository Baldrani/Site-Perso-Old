<?php include('universalHead.php'); ?>
    <title></title>
    </head>
    <body>
<div class="wrapper">
    <?php /*
			echo '<pre>';
			print_r($_SESSION);
		 	echo '</pre>';
		*/ ?>
    <?php if (isset($_SESSION['idutilisateur'])) include("header.php"); ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Content -->
            <div class="titre col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h1> Liste de mes sports</h1>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php
            if (isset($_POST["bouton"]) && !empty($_POST["lieu"])) {
                $sport = $_POST["sport"];
                $niveau = $_POST["niveau"];
                $idutilisateur = $_SESSION["idutilisateur"];
                $req = "SELECT idSport FROM sport WHERE sport = \"$sport\"";
                $res = $conn->query($req);
                $temp = $res->fetch(PDO::FETCH_OBJ);
                $idSport = $temp->idSport;
                // fonction pour enlever tous les accents
                // DEBUT
                function suppr_accents($str, $encoding = 'utf-8')
                {
                    // transformer les caractères accentués en entités HTML
                    $str = htmlentities($str, ENT_NOQUOTES, $encoding);

                    // remplacer les entités HTML pour avoir juste le premier caractères non accentués
                    // Exemple : "&ecute;" => "e", "&Ecute;" => "E", "Ã " => "a" ...
                    $str = preg_replace('#&([A-za-z])(?:acute|grave|cedil|circ|orn|ring|slash|th|tilde|uml);#', '\1', $str);

                    // Remplacer les ligatures tel que : Œ, Æ ...
                    // Exemple "Å“" => "oe"
                    $str = preg_replace('#&([A-za-z]{2})(?:lig);#', '\1', $str);
                    // Supprimer tout le reste
                    $str = preg_replace('#&[^;]+;#', '', $str);

                    return $str;
                }

                // FIN
                $lieu = str_replace(' ', '', strtoupper(suppr_accents($_POST["lieu"])));//on enlève les accents, on met en majuscule et on enlève les espaces
                $reqS = "SELECT idPratique FROM pratique, lieu, niveau
						WHERE lieu.idLieu = pratique.idLieu
						AND pratique.idNiveau = niveau.idNiveau
						AND pratique.idSport = $idSport
						AND pratique.idNiveau = (SELECT idNiveau from niveau WHERE niveau =\"$niveau\")
						AND pratique.idutilisateur = $idutilisateur
						AND pratique.idLieu = (SELECT idLieu from lieu WHERE ville = \"$lieu\")";
                $resS = $conn->query($reqS);
                $resultat = $resS->fetch(PDO::FETCH_OBJ);
                if ($resultat->idPratique == NULL) {
                    $req = "SELECT ville FROM lieu";
                    $res = $conn->query($req);
                    $ligne = $res->fetch(PDO::FETCH_OBJ);
                    $trouve = false;
                    while ($ligne && $trouve == false) {
                        if ($ligne->ville == $lieu) {
                            $trouve = true;
                            $req2 = "SELECT idLieu FROM lieu WHERE ville = \"$lieu\"";
                            $res2 = $conn->query($req2);
                            $temp = $res2->fetch(PDO::FETCH_OBJ);
                            $idLieu = $temp->idLieu;
                            $req3 = "INSERT INTO pratique (idSport, idNiveau, idutilisateur, idLieu)
						VALUES (\"$idSport\",(SELECT idNiveau FROM niveau WHERE niveau = \"$niveau\"),\"$idutilisateur\",\"$idLieu\")";
                            $conn->query($req3);
                        }
                        $ligne = $res->fetch(PDO::FETCH_OBJ);
                    }
                    if ($trouve == false) {
                        $req = "INSERT INTO lieu (ville, idLieu) VALUES (\"$lieu\", NULL)";
                        $conn->query($req);
                        $req = "SELECT idLieu FROM lieu WHERE ville = \"$lieu\"";
                        $res = $conn->query($req);
                        $temp = $res->fetch(PDO::FETCH_OBJ);
                        $idLieu = $temp->idLieu;
                        $req = "INSERT INTO pratique (idSport, idNiveau, idutilisateur, idLieu)
						VALUES (\"$idSport\",(SELECT idNiveau FROM niveau WHERE niveau = \"$niveau\"),\"$idutilisateur\",\"$idLieu\")";
                        $conn->query($req);
                    }
                } else {
                    $error[] = "Cette ligne existe déjà !";
                }
            } else if (isset($_POST["bouton"]) && empty($_POST["lieu"])) {
                $error[] = "Veuillez remplir un lieu avant de soumettre le formulaire !";
            }
            //traitement de la suppression d'un sport d'un utilisateur
            if (isset($_GET["idPratique"]) && !empty($_GET["idPratique"])) {
                $idPratique = $_GET["idPratique"];
                $req = "DELETE FROM pratique WHERE idPratique = $idPratique";
                $conn->query($req);
            }
            // S'il y a des sports associés à l'utilisateur dans la DB on affiche le tableau les contenant
            $idutilisateur = $_SESSION["idutilisateur"];
            $req3 = "SELECT l.ville, s.sport, n.niveau, p.idPratique FROM lieu l, sport s, pratique p, niveau n 
						WHERE l.idLieu = p.idLieu 
						AND s.idSport = p.idSport 
						AND n.idNiveau = p.idNiveau 
						AND p.idutilisateur = $idutilisateur 
						ORDER BY p.idPratique ASC";
            $res = $conn->query($req3);
            if ($res != NULL) {
                ?>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="panel panel-default ">
                        <div class="panel-heading">
                            <table class="table">
                                <tr bgcolor="#009EE0">
                                    <th>Sport</th>
                                    <th>Niveau</th>
                                    <th>Lieu</th>
                                    <th>Suppression</th>
                                </tr>
                                <?php
                                while ($row = $res->fetch(PDO::FETCH_OBJ)) {
                                    echo "<tr>
    								<td>" . $row->sport . "</td>
    			     				<td>" . $row->niveau . "</td>
    								<td>" . $row->ville . "</td>
    		      					<td><a href=\"mesSports.php?idPratique=" . $row->idPratique . "\"><img src=\"../public/images/croixRouge.png\"/></a></td>				
									</tr>";
                                }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
                <?php
            } else {
                $warning[] = "Vous n'êtes inscrit à aucun sport pour l'instant !";
            }
            ?>
            <!-- AFFICHAGE DU FORMULAIRE POUR AJOUTER UN SPORT-->
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <?php
                $req1 = "SELECT sport FROM sport";
                $res1 = $conn->query($req1);
                $ligne1 = $res1->fetch(PDO::FETCH_OBJ);
                echo "<form class=\"formulaire\" action=\"mesSports.php\" method=\"POST\" name=\"formSport\">";
                echo "<br/>Sport : <select name=\"sport\" class=\"form-control menuSelect2\">";
                while ($ligne1) {
                    echo "<option>" . $ligne1->sport . "</option>";
                    $ligne1 = $res1->fetch(PDO::FETCH_OBJ);
                }
                echo "</select><br/>"; ?>
                Niveau : <select class="form-control menuSelect2" name="niveau">
                    <?php
                    $reqN = "SELECT niveau FROM niveau";
                    $resN = $conn->query($reqN);
                    $ligneN = $resN->fetch(PDO::FETCH_OBJ);
					while ($ligneN) {
                        echo "<option>" . $ligneN->niveau . "</option>";
                        $ligneN = $resN->fetch(PDO::FETCH_OBJ);
                    }
					?>

                </select><br/>
                <?php
                echo "Lieu : <input type=\"text\" name=\"lieu\" class=\"form-control\"/>";
                echo "<input type=\"submit\" value=\"Ajouter !\" name=\"bouton\" class=\"bouton-envoyer\"/>";
                echo "</form>";
                ?>
                <br/>
            </div>
            <!-- End Content -->
            <!-- Succes et Error -->
            <div class="row">
                <div class="col-xs-offset-2 col-xs-8">
                    <br><br>
                    <?php 
                    if(count($succes) > 0){
                        foreach( $succes as $s )  
                        {  
                            echo( "<div class='alert alert-success' role='alert'>$s</div>" );  
                        }
                    }
                    if(count($warning) > 0){
                        foreach( $warning as $s )  
                        {  
                            echo( "<div class='alert alert-warning' role='alert'>$s</div>" );  
                        }
                    }
                    if(count($error) > 0){
                        foreach( $error as $s )  
                        {  
                            echo( "<div class='alert alert-danger' role='alert'>$s</div>" );  
                        }
                    }
                    ?>                      
                </div>
            </div>
            <!-- End affichage succes et Error -->
        </div>
    </div>
</div>
<?php include('universalFooter.php') ?>