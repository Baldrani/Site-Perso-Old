<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php">Sos Partenaires</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
            <li><a href="partenaires.php">Partenaires disponibles</a></li>
      </ul>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="mesSports.php">Mes Sports</a></li>
            <li><a href="formulairesMonCompte.php">Mon compte</a></li>
            <li><a href="deco.php"><button type="button" class="headerPerso btn btn-primary navbar-btn">Deconnexion</button></a></li>
        </ul>
    </div>
  </div>
</nav>
