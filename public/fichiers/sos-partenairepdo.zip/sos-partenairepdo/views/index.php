<?php include('universalHead.php'); ?>
	<title></title>
	</head>
	<body>
		<div class="wrapper">
			<?php if(isset($_SESSION['idutilisateur'])) include("header.php"); ?>
			<!-- Content -->
			<?php 
				if(!empty($_SESSION['flag'])){
					$error [] = $_SESSION['flag'];
					unset($_SESSION['flag']);
				}
				//Si un utilisateur se connecte
				if(isset($_POST["login"]))
				{
					$_SESSION['flag'] = 'Erreur dans les données de connexion';
					$username = $_POST["username"];
					$password = $_POST["password"];

					//On attribu les données aux variables de session.
					$query = "Select * from utilisateur where identifiant='$username' and mdp='$password'";
					$req = $conn->query($query);
					while($d = $req->fetch(PDO::FETCH_OBJ)){
						$_SESSION["idutilisateur"] = $d->idutilisateur;
						$_SESSION["nom"]		   = $d->nom;
						$_SESSION["prenom"]  	   = $d->prenom;
						$_SESSION["identifiant"]   = $d->identifiant;
						$_SESSION["mdp"] 		   = $d->mdp;
						$_SESSION["email"] 		   = $d->email;
						$_SESSION["telephone"] 	   = $d->telephone;
					}

					//On redirige vers une autre page + Gestion des bullshit à faire !
					if(isset($_SESSION["idutilisateur"])){
						unset($_SESSION['flag']);
						echo '<script>window.location = "partenaires.php";</script>';
					}

					// echo '<pre>';
					// 				var_dump($_SESSION);
					// echo '</pre>';

				}
			?>
			<?php
				//Si un utilisateur s'inscrit
				if(isset($_POST["inscription"]))
				{
					$nom 		 = $_POST["nom"];
					$prenom		 = $_POST["prenom"];
					$identifiant = $_POST["identifiant"];
					$mdp		 = $_POST["mdp"];
					$email 		 = $_POST["email"];
					$telephone	 = $_POST["telephone"];

					$req = "insert into utilisateur (nom, prenom, identifiant, mdp, email, telephone)
									values ('$nom','$prenom','$identifiant', '$mdp','$email','$telephone')";

					$res = $conn->exec($req);
					if($res){
						$query = "SELECT idutilisateur FROM utilisateur WHERE identifiant = '$identifiant' ";
						$req = $conn->query($query);
						$row = $req->fetch();
						$_SESSION['idutilisateur'] = $row['idutilisateur'];
						echo '<script>window.location = "partenaires.php";</script>';
					} else {
						//Gérer les différentes érreur à l'enregistrement
						$error[] = "Il y a eu une érreur lors de votre enregistrement.";
					}

					//Rediriger + Verifier les données
				}
			?>
			<div class="container-fluid">
				<div class="row">
					<div class="acc">
		            	SOS Partenaires
		            </div>
				</div>
				<br><br>
				<?php //Si la personne n'est pas membre 
				if(!isset($_SESSION['idutilisateur'])) {
				?>
					<div class="row">
			            <div class="col-md-offset-2 col-md-4 col-xs-offset-2 col-xs-4">
			              	<a href="#connexion" data-toggle="modal">
			              		<div class="btn-lg btn-default">
			                  	Connexion
			              		</div>
			              	</a>
			            </div>
			            <div class="col-md-4 col-xs-4">
			              	<a href="#inscription" data-toggle="modal">
				              	<div class="btn-lg btn-default">
				                  Inscription
				              	</div>
			              	</a>
			            </div>
			         </div>
				<div class="modal fade" id="connexion" role="dialog">
	                <div class="modal-dialog">
	                    <div class="modal-content">
	                        <form id="FormConnexion" action="index.php" method="post" onsubmit=" return verifForm(this)">
	                            <div class="modal-header">
	                                <h4 class="text-center">Connexion</h4>
	                            </div>
	                            <div class="modal-body">
	                                <div class="row">
	                                    <div class="col-md-offset-3 col-md-6">
	                                        <input type="text" class="form-control" name="username" id="identifiant" placeholder="Identifiant" onblur="verifLog(this)" />
	                                    </div>
	                                </div><br/>

	                                <div class="row">
	                                    <div class="col-md-offset-3 col-md-6">
	                                        <input type="password" class="form-control" name="password" id="password" placeholder="Mot de Passe" onblur="verifPass(this)">
	                                    </div>
	                                </div><br/>

	                                <div class="modal-footer">
	                                    <input class="btn btn-primary" type="submit" value="Connexion" name="login" >
	                                    <a class="btn btn-default" data-dismiss="modal">Annuler</a>
	                                </div>
	                            </div>
	                        </form>
	                    </div>
	                </div>
	            </div>
				<div class="modal fade" id="inscription" role="dialog">
	                <div class="modal-dialog">
	                    <div class="modal-content">
	                        <form id="FormIns" action="index.php" method="post">
	                            <div class="modal-header">
	                                <h4 class="text-center">Inscription</h4>
	                            </div>

	                            <div class="modal-body">
	                              <div class="row">
	                                  <div class="col-md-offset-3 col-md-6">
	                                      <input type="text" class="form-control" name="nom" id="nom" placeholder="Nom">
	                                  </div>
	                              </div><br/>

	                              <div class="row">
	                                  <div class="col-md-offset-3 col-md-6">
	                                      <input type="text" class="form-control" name="prenom" id="fname" placeholder="Prénom">
	                                  </div>
	                              </div><br/>

	                                <div class="row">
	                                    <div class="col-md-offset-3 col-md-6">
	                                        <input type="text" class="form-control" name="identifiant" id="identifiant" placeholder="Identifiant">
	                                    </div>
	                                </div><br/>

	                                <div class="row">
	                                    <div class="col-md-offset-3 col-md-6">
	                                        <input type="password" class="form-control" name="mdp" id="mdp" placeholder="Mot de Passe">
	                                    </div>
	                                </div><br/>

	                                <div class="row">
	                                    <div class="col-md-offset-3 col-md-6">
	                                        <input type="password" class="form-control" name="cnpass" id="confmdp" placeholder="Confirmer Mot de Passe">
	                                    </div>
	                                </div><br/>

	                                <div class="row">
	                                    <div class="col-md-offset-3 col-md-6">
	                                        <input type="text" class="form-control" name="email" id="email" placeholder="Adresse Email">
	                                    </div>
	                                </div><br/>

	                                <div class="row">
	                                    <div class="col-md-offset-3 col-md-6">
	                                        <input type="text" class="form-control" name="telephone" id="telephone" placeholder="Numéro de Téléphone">
	                                    </div>
	                                </div><br/>

	                                <div class="modal-footer">
	                                    <input class="btn btn-primary" type="submit" value="Inscription" name="inscription" >
	                                    <a class="btn btn-default" data-dismiss="modal">Annuler</a>
	                                </div>
	                            </div>
	                        </form>
	                    </div>
	                </div>
	            </div>
				<?php } ?> 
			</div>
			<!--End Content -->
			<!-- Succes et Error -->
			<div class="container-fluid">
				<div class="row">
					<div class="col-xs-offset-2 col-xs-8">
						<br><br>
						<?php
						if(count($succes) > 0){
							foreach( $succes as $s )
							{
								echo( "<div class='alert alert-success' role='alert'>$s</div>" );
							}
						}
						if(count($warning) > 0){
							foreach( $warning as $s )
							{
								echo( "<div class='alert alert-warning' role='alert'>$s</div>" );
							}
						}
						if(count($error) > 0){
							foreach( $error as $s )
							{
								echo( "<div class='alert alert-danger' role='alert'>$s</div>" );
							}
						}
						?>
					</div>
				</div>
			</div>
			<!-- End affichage succes et Error -->
		</div>
	<?php include('universalFooter.php') ?>