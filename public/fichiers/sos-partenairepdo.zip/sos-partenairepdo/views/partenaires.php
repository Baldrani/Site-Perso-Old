<?php include('universalHead.php'); ?>
	<title></title>
	</head>
	<body>
		<div class="wrapper">
		<?php 
			// echo '<pre>';
			// print_r($_SESSION);
		 // 	echo '</pre>';
		 ?>
			<?php if(isset($_SESSION['idutilisateur'])) include("header.php"); ?>
			<div class="container-fluid">
				<div class="row">
					<!-- Content -->
					<div class="titre col-xs-12">
						<h1>  Recherche de partenaires </h1>
					</div>
				</div>
			</div>
			<div class="container">
				<div class="row">
					<!-- Partie Sport -->
					<?php
						$query = "Select distinct sport from sport, pratique where pratique.idUtilisateur = ".$_SESSION['idutilisateur']." and pratique.idSport = sport.idSport order by sport ASC";
						$req = $conn->query($query);
						//Si l'utilisateur a au moins un sport
						if(count($req->fetchAll()) > 0){ ?>
							<div class=" col-lg-5 col-sm-10  col-sm-offset-1 col-xs-12">
								    <form class="formulaire" method='POST' action='partenaires.php'>
								    	<div class="col-lg-12 col-md-12 col-sm-12 clo-xs-12">
											Vos sports : 
										</div>
										<div class="clear-left"></div>
										<div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 ">
											<select class="menu-deroulant menuSelect2" name="choixSport"> <!-- Menu déroulant -->	
												<!-- Récupérer les information du menu déroulant -->
												<option selected=\"true\"> </option>"; <!-- champs vide dans menu déroulant -->
												<?php
												$query = "Select distinct * from sport, pratique where pratique.idUtilisateur = ".$_SESSION['idutilisateur']." and pratique.idSport = sport.idSport GROUP BY sport ORDER BY sport ASC";
												$req = $conn->query($query);
												while($d = $req->fetch(PDO::FETCH_OBJ)){
													echo "<option value='$d->idsport'>$d->sport</option>";
												}
												?>
											</select>
										</div>
										<div class="clear-left"></div>
										<div class="formulaire-bouton col-lg-12 col-md-12 col-sm-12 clo-xs-12">
											<input class="bouton-envoyer" type="submit" value="Envoyer"/> <!-- Bouton envoyer -->
										</div>
										<div class="clear-left"></div>
									</form>
							</div>
						<?php 
						//S'il n'as pas de sport
						} else { 
							$warning[] = "Vous n'avez enregisré aucun sport à ce jour !";
						} 
						// <!-- Listing des partenaires en fonction d'un sport -->
						if(isset($_POST["choixSport"])){
							//Si il n'as aps choisi de sport 
							if($_POST["choixSport"]==NULL){ 
								$error[]=  "Veuillez choisir un sport !";
							//Si un sport est séléctionné
							} else {					
								/*--------------- Récupérer la liste en fonction de l'idSport ---------------*/
								$query = "select identifiant, ville, niveau, telephone, email, sport
										  from pratique, utilisateur, lieu, sport, niveau
										  where sport.idSport = " . $_POST['choixSport'] . " 
										  and pratique.idSport = sport.idSport
										  and utilisateur.idutilisateur != ".$_SESSION['idutilisateur']."
										  and pratique.idutilisateur = utilisateur.idutilisateur
										  and pratique.idLieu = lieu.idLieu
	 									  and pratique.idNiveau = niveau.idNiveau";
	 							$req = $conn->query($query);
	 							if($req->rowCount() < 1){ 
	 								$warning[] = "Désolé, il n'y a aucun partenaire disponible pour ce sport.";
	 							} else {
	 								$res = '
	 								<div class="row">
		 								<div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
											<div class="panel panel-default" id="panel-default">
												<div class="panel-heading">
													<h3></h3>
													<table class="table">
													<tr bgcolor="#009EE0"><th>Identifiant</th><th>Lieu</th><th>Niveau</th><th>Joindre</th></tr>
													';
													while($d = $req->fetch(PDO::FETCH_OBJ)){
													$res .= "<tr>
													<td>" .$d->identifiant. "</td>
													<td>" .$d->ville. "</td>
													<td>" .$d->niveau. "</td>
													<td>
													<form method='POST' action='partenaires.php'>
													<input type=\"hidden\" value='$d->identifiant' name='identifiant'>
													<input type=\"hidden\" value='$_POST[choixSport]' name='sport'>
													<input type=\"hidden\" value='$d->ville' name='ville1'>
													<button type=\"submit\" name=\"contacter\">Contacter</button>
													</form>
													</td>
													</tr>";
													}
													$res .= '
													</table>
												</div>
											</div>
										</div> 
									</div>';
	 							}
	 						}
	 					}
					?>
					<!-- Partie Lieu -->
					<?php 
						$query = "SELECT DISTINCT ville FROM lieu, pratique WHERE pratique.idutilisateur = ".$_SESSION['idutilisateur']." and pratique.idlieu = lieu.idlieu ORDER by ville ASC";
						$req = $conn->query($query);
						//Si l'utilisateur a au moins un lieu
						if(count($req->fetchAll()) > 0){
						?>
							<div class=" col-lg-5  col-sm-10 col-sm-offset-1 col-xs-12">
								<form class="formulaire" method='POST' action='partenaires.php' name="lieu">
								    	<div class="col-lg-12 col-md-12 col-sm-12 clo-xs-12">
											Vos lieux : 
										</div>
										<div class="clear-left"></div>
										<div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 ">
											<select class="menu-deroulant menuSelect2" name="choixLieu"> <!-- Menu déroulant -->	
												<!-- Récupérer les information du menu déroulant -->
												<option selected=\"true\"> </option>"; <!-- champs vide dans menu déroulant -->
												<?php
												$query = "SELECT DISTINCT * FROM lieu, pratique WHERE pratique.idutilisateur = ".$_SESSION['idutilisateur']." and pratique.idlieu = lieu.idlieu GROUP BY ville ORDER by ville ASC";
												$req = $conn->query($query);
												while($d = $req->fetch(PDO::FETCH_OBJ)){
													echo "<option value='$d->idlieu'>$d->ville</option>";
												}
												?>
											</select>
										</div>
										<div class="clear-left"></div>
										<div class="formulaire-bouton col-lg-12 col-md-12 col-sm-12 clo-xs-12">
											<input class="bouton-envoyer" type="submit" value="Envoyer" name="lieu"/> <!-- Bouton envoyer -->
										</div>
										<div class="clear-left"></div>
								</form>
							</div>
					<?php
					// <!-- Listing des partenaires en fonction d'un lieu -->
						if(isset($_POST["choixLieu"])){
							//Si il n'as aps choisi de lieu 
							if($_POST["choixLieu"]==NULL){ 
								$error[]=  "Veuillez choisir un lieu !";
							//Si un lieu est séléctionné
							} else {					
								/*--------------- Récupérer la liste en fonction de l'idlieu ---------------*/
								$query = "	select identifiant, sport, niveau, telephone, email 
											from pratique, utilisateur, lieu, sport, niveau
											where lieu.idlieu = " . $_POST['choixLieu'] . " 
											and pratique.idSport = sport.idSport
											and utilisateur.idutilisateur != ".$_SESSION['idutilisateur']."
											and pratique.idutilisateur = utilisateur.idutilisateur
											and pratique.idLieu = lieu.idLieu
											and pratique.idNiveau = niveau.idNiveau";
	 							$req = $conn->query($query);
	 							if($req->rowCount() < 1){ 
	 								$warning[] = "Désolé, il n'y a aucun partenaire disponible dans ce lieu.";
	 							} else {
	 								$res = '
	 								<div class="row">
		 								<div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
											<div class="panel panel-default" id="panel-default">
												<div class="panel-heading">
													<table class="table">
													<tr bgcolor="#009EE0"><th>Identifiant</th><th>Sport</th><th>Niveau</th><th>Joindre</th></tr>
													';
													while($d = $req->fetch(PDO::FETCH_OBJ)){
													$res .= "<tr>
													<td>" .$d->identifiant. "</td>
													<td>" .$d->sport. "</td>
													<td>" .$d->niveau. "</td>
													<td>
													<form method='POST' action='partenaires.php'>
													<input type=\"hidden\" value='$d->identifiant' name='identifiant'>
													<input type=\"hidden\" value='$_POST[choixLieu]' name='ville'>
													<input type=\"hidden\" value='$d->sport' name='sport1'>
													<button type=\"submit\" name=\"contacter\">Contacter</button>
													</form>
													</td>
													</tr>";
													}
													$res .= '
													</table>
												</div>
											</div>
										</div> 
									</div>';
	 							}
	 						}
	 					}
						}
					if(!empty($res)) echo $res;
					//Envoyer un mail au destinataire.
					if(isset($_POST['contacter'])){
						//Selectionne l'adresse du detinataire
						$query = "SELECT email from utilisateur where identifiant = \"$_POST[identifiant]\"";
						$req = $conn->query($query);
						$res = $req->fetch();
						$to = "$res[0]";
						//Si à partir de "Vos Sport"
						if(isset($_POST['sport'])){
							$query = "SELECT sport from sport where idsport = $_POST[sport]";
							$req = $conn->query($query);
							$res = $req->fetch();
							$message = "Le membre ".$_SESSION['identifiant']." souhaite vous contacter pour la pratique du sport : $res[0] à $_POST[ville1]";
						}
						//Si à partir de "Vos Lieux"
						if(isset($_POST['ville'])){
							$query = "SELECT ville from lieu where idlieu = $_POST[ville]";
							$req = $conn->query($query);
							$res = $req->fetch();
							$message = "Le membre ".$_SESSION[identifiant]." souhaite vous contacter pour la pratique de : $_POST[sport1] à $res[0]";
						}
						$message .= "\n\n Vous pouvez le recontacter à l'adresse suivante : $_SESSION[email]";

						$subject = "Demande de rencontre entre partenaire [Sos Partenaire]";
						mail ($to , $subject , $message);

						$_SESSION['succes'] = "Un mail contenant votre pseudo et votre adresse mail à été envoyé à votre eventuel partenaire.<br>Ne tient plus qu'à lui de vous répondre ou non.";
					}
					?>
					</div>
						

					<!-- End Content -->
					<!-- Succes et Error -->
					<div class="row">
						<div class="col-xs-offset-2 col-xs-8">
							<br><br>
							<?php
							if(!empty($_SESSION['succes'])){
									$succes [] = $_SESSION['succes'];
									unset($_SESSION['succes']);
							}
							if(!empty($_SESSION['warning'])){
									$warning [] = $_SESSION['warning'];
									unset($_SESSION['warning']);
							}
							if(!empty($_SESSION['error'])){
									$error [] = $_SESSION['error'];
									unset($_SESSION['error']);
							}
							if(count($succes) > 0){
						        foreach( $succes as $s )  
					            {  
					                echo( "<div class='alert alert-success' role='alert'>$s</div>" );  
					            }
					       	}
					       	if(count($warning) > 0){
						        foreach( $warning as $s )  
					            {  
					                echo( "<div class='alert alert-warning' role='alert'>$s</div>" );  
					            }
					       	}
							if(count($error) > 0){
						        foreach( $error as $s )  
					            {  
					                echo( "<div class='alert alert-danger' role='alert'>$s</div>" );  
					            }
					       	}
						    ?>						
						</div>
					</div>
					<!-- End affichage succes et Error -->
				</div>
			</div>
		</div>
	<?php include('universalFooter.php') ?>