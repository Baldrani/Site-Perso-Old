<?php session_start();

//Redirige si non connecté
if ($_SERVER['REQUEST_URI'] != "/sos-partenairepdo/views/"){
	if(empty($_SESSION['idutilisateur'])){
		header("Location: " . "http://" . $_SERVER['HTTP_HOST'] . "/sos-partenairepdo/views/");
	}
}
// Connexion
try{
	if(substr($_SERVER['HTTP_HOST'],0,9) == "localhost"){
		  if(PHP_OS == "Darwin") $conn = new PDO('mysql:host=localhost:8889;dbname=sos', 'root','root'); //Unix
		  else $conn = new PDO('mysql:host=localhost;dbname=sos', 'root',''); //Window
	} else {
		$conn = new PDO('mysql:host=mysql55-39.perso;dbname=maelmayoezsio', 'maelmayoezsio','BtsSIO2016');			
	}
}
catch (PDOException $e) 
{
	echo "La base de donnée n'est pas disponible de suite ou il y'a des problèmes dans les données de connexion";
	echo ' -----> Exception : '.$e;
}
$conn->exec("SET CHARACTER SET utf8");
//On déclare les flags sur toutes les pages
$error = [];
$warning = [];
$succes = [];
?>
<!doctype html>
<html>
	<head>
	<!-- Latest compiled and minified CSS -->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- jQuery -->
	<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
	<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>

	<!-- Select2 -->
	<link href="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css" rel="stylesheet" />
	<script src="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.min.js"></script>

	<!-- Boostrap -->
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

	<!-- CSS/SASS -->
	<link href="../public/stylesheets/screen.css" media="screen, projection" rel="stylesheet" type="text/css" />
	<link href="../public/stylesheets/print.css" media="print" rel="stylesheet" type="text/css" />
	<!--[if IE]>
	<link href="../public/stylesheets/ie.css" media="screen, projection" rel="stylesheet" type="text/css" />
	<![endif]-->

	<!-- Google Font -->
	<link href='http://fonts.googleapis.com/css?family=Slabo+27px' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>