<?php include('universalHead.php'); ?>
	<title></title>
	</head>
	<body>
		<div class="wrapper">
		<?php /*
			echo '<pre>';
			print_r($_SESSION);
		 	echo '</pre>';
		*/ ?>
			<?php if(isset($_SESSION['idutilisateur'])) include("Header.php"); ?>
			<div class="container-fluid">
				<div class="row">
					<!-- Content -->
						
					<!-- End Content -->
				</div>
			</div>
		</div>
	<?php include('universalFooter.php') ?>