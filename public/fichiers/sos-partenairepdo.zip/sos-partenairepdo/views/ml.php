<?php include('universalHead.php'); ?>
    <title></title>
    </head>
    <body>
        <div class="wrapper">
            <?php if(isset($_SESSION['idutilisateur'])) include("Header.php"); ?>
            <div class="container-fluid">
                <div class="row">
                    <!-- Content -->
                                <div class="col-md-offset-2 col-md-8">
          <div class="cgu">
            <h2 class="align-center">Mentions Legales</h2><br>
            Le site web www.sos-partenaires.fr est édité par Société du Sos Partenaires, SAS au capital de 16.860.475 €, dont le siège est sis 14, boulevard Haussmann, 75009 PARIS, immatriculée au registre du commerce et des sociétés de Paris sous le numéro 542 077 755, dont les coordonnées sont les suivantes :

            coordonnées téléphoniques : 01 53 08 80 40

            numéro individuel d’identification de TVA : 50542072155

            Directeur de la Publication: Maël Mayon

            Directeur des Rédactions : Maxime Rieu

            Le site est hébergé par SDV Plurimédia, 15, rue de la Nuéee Bleue, 67000 STRASBOURG - Tel: 03 88 75 80 50,

            étant précisé que la rubrique santé du site, accessible via l’url http://sante.sos-partenaires.fr/, est hébergée par la société Claranet (Typhon), 18, rue du Faubourg du Temple, 75011 PARIS - Tel: 01 70 61 66 16 / 01 79 97 11 11.
            <br>
            <h4 class="align-center">Propriete Intellectuelle – Droits Concedes Aux Utilisateurs</h4><br>

            L’utilisateur du site www.sos-partenaires.fr s'interdit de reproduire et/ou d'utiliser les marques et logos présents sur le site, ainsi que de modifier, copier, traduire, reproduire, vendre, publier, exploiter et diffuser dans un format numérique ou autre, tout ou partie des informations, textes, photos, images, vidéos et données présents sur le site, qui constituent des œuvres au sens des dispositions de l’article L112-1 du code de la propriété intellectuelle.

            La violation de ces dispositions impératives soumet le contrevenant, et toutes personnes responsables, aux peines pénales et civiles prévues par la loi.

            Société du Sos Partenaires consent à l’utilisateur du site un droit d’usage privé, non collectif et non exclusif sur son contenu. Ce droit est limité au droit d’imprimer un ou plusieurs articles et/ou de l’enregistrer sur son ordinateur (ou autre support digital tel que mobile et tablette) pour son usage personnel exclusivement (y compris dans le cadre d’un abonnement pour les contenus payants). Toute mise en réseau, toute rediffusion, toute exploitation dans un cadre professionnel ou commercial ou toute commercialisation de ce contenu auprès de tiers, sous quelque forme que ce soit, est strictement interdite sauf accord préalable de Société du Sos Partenaires. Il en est de même des flux RSS et les newsletters. Les personnes souhaitant exploiter ou utiliser tout ou partie du contenu du site dans un cadre professionnel ou commercial, et en particulier, les flux RSS, sont invitées à contacter le service Droits et Reproduction (à l’adresse « syndication-service@sos-partenaires.fr »).
            <br>
            <br>
            <h4 class="align-center">Donnees Personnelles</h4>
            <br>
            Le recueil et le traitement des données personnelles par Société du Sos Partenaires qui lui sont transmises sur le site www.sos-partenaires.fr ont fait l'objet de la déclaration n° 1797617 auprès de la CNIL (ainsi que la déclaration n°17495 s’agissant des données collectées lors de ventes par correspondance et de la souscription d’abonnements payants). Conformément à la loi "Informatique et Libertés" du 6 janvier 1978, vous disposez d'un droit d'accès, de rectification, de modification et de suppression concernant les données qui vous concernent. Pour l'exercer, adressez vous à : serviceclientweb@sos-partenaires.fr, en nous indiquant vos nom, prénom et adresse e-mail.


            <br><br>
            <h4 class="align-center">Droits De Reproduction- Syndication</h4>
            <br>
            Vous êtes un professionnel/vous souhaitez utiliser nos contenus pour un usage professionnel ?

            Si vous souhaitez reproduire un ou plusieurs articles/contenus du Sos Partenaires ou utiliser la UNE et/ou un exemplaire du journal pour un usage professionnel, nous vous invitons à contacter notre service chargé des Droits de Reproduction, à l'adresse suivante syndication-service@sos-partenaires.fr ou en téléphonant au 01 57 08 59 69.

            Pour les photos et illustrations (infographie), retrouvez toutes les photos du Sos Partenaires sur le site www.Sos Partenairesphoto.com (site réservé aux professionnels).

            Vous êtes un particulier/vous souhaitez utiliser nos contenus pour un usage privé ?

            Si vous souhaitez acheter un numéro récent du journal (moins de 6 mois), contactez notre service des ventes à l’adresse suivante : Le Sos Partenaires Service Vente 14, boulevard Haussmann 75438 Paris Cedex 09 ou par téléphone aux numéros suivants : 01 57 08 71 10 ou 01 57 08 71 08.

            Pour les numéros plus anciens, nous vous conseillons de vous adresser aux librairies spécialisées.

            Pour acheter une UNE du Sos Partenaires, veuillez vous connecter sur la boutique Sos Partenaires Store à l’adresse http://boutique.sos-partenaires.fr.

            ATTENTION : pour toute reproduction à usage professionnel, merci de contacter notre service chargé des Droits de Reproduction, à l'adresse suivante syndication-service@sos-partenaires.fr  ou au 01 57 08 59 69



            Consultation d’une annonce publiée dans le Carnet du jour

            La rubrique Le carnet du jour est consultable depuis juillet 2007 sur le site web du Sos Partenaires à l'adresse suivante http://carnetdujour.sos-partenaires.fr/
            <br><br>
          </div>

                    <!-- End Content -->
                </div>
            </div>
        </div>
    <?php include('universalFooter.php') ?>

