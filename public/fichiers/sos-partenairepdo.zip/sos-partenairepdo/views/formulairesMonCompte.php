<?php include('universalHead.php'); ?>
	<title></title>
	</head>
	<body>
		<div class="wrapper">
			<?php if(isset($_SESSION['idutilisateur'])) include("header.php");?>

			<div class="container-fluid">
				<div class="row">
					<!-- Content -->
					<!-- Partie Num et Mail -->
					<?php
						if(isset($_POST['btMailNum'])){
							$newNom      = $_POST['newNom'];
							$queryNom    = "Update sos.utilisateur SET nom = \"$newNom\" WHERE idutilisateur = '$_SESSION[idutilisateur]'";
							$newPrenom    = $_POST['newPrenom'];
							$queryPrenom = "Update sos.utilisateur SET prenom = \"$newPrenom\" WHERE idutilisateur = '$_SESSION[idutilisateur]'";
							$newPseudo   = $_POST['newPseudo'];
							$queryPseudo = "Update sos.utilisateur SET nom = \"$newPseudo\" WHERE idutilisateur = '$_SESSION[idutilisateur]'";
							$newMail     = $_POST['newMail'];
							$queryMail   = "Update sos.utilisateur SET email = \"$newMail\" WHERE idutilisateur = '$_SESSION[idutilisateur]'";
							$newNum      = $_POST['newNum'];
							$queryNum    = "Update sos.utilisateur SET telephone = \"$newNum\" WHERE idutilisateur = '$_SESSION[idutilisateur]'";

							if($_SESSION['nom'] != $newNom){
								$q = $conn->query($queryNom);
								$_SESSION['nom'] = $newNom;
								$succes[] = "Votre nom a bien été mis à jour.";
							}

							if($_SESSION['prenom'] != $newPrenom){
								$q = $conn->query($queryPrenom);
								$_SESSION['prenom'] = $newPrenom;
								$succes[] = "Votre prenom a bien été mis à jour.";
							}
							if($_SESSION['identifiant'] != $newPseudo){
								$q = $conn->query($queryPseudo);
								$_SESSION['identifiant'] = $newPseudo;
								$succes[] = "Votre identifiant a bien été mis à jour.";
							}
							if($_SESSION['email'] != $newMail){
								$q = $conn->query($queryMail);
								$_SESSION['email'] = $newMail;
								$succes[] = "Votre mail a bien été mis à jour.";
							}
							if($_SESSION['telephone'] != $newNum){
								$q = $conn->query($queryNum);
								$_SESSION['telephone'] = $newNum;
								$succes[] = "Votre numéro a bien été mis à jour.";
							}

							if($_SESSION['nom'] == $newNom && $_SESSION['prenom'] == $newPrenom && $_SESSION['identifiant'] == $newPseudo && $_SESSION['email'] == $newMail && $_SESSION['telephone'] == $newNum){
								$warning[] = "Vous n'avez pas changé vos données personnelles.";
							}

						}
					?>
					<div class="col-sm-offset-2 col-sm-4 col-xs-offset-1 col-xs-10">
						<h4><strong>Modification données personnelles :</strong></h4>
						<br/>	
						<form action="formulairesMonCompte.php" method="post">
						<input class="form-control" type="text" name="newNom" value="<?php echo $_SESSION['nom']; ?>" max-length="30" min-lenght="1"/>
						<input class="form-control" type="text" name="newPrenom" value="<?php echo $_SESSION['prenom']; ?>" max-length="30" min-lenght="1"/>
						<input class="form-control" type="text" name="newPseudo" value="<?php echo $_SESSION['identifiant']; ?>" max-length="30" min-lenght="3"/>
						<input class="form-control" type="email" name="newMail" value="<?php echo $_SESSION['email']; ?>" max-length="30"/>
						<input class="form-control" type="text" name="newNum" value="<?php echo  $_SESSION['telephone']; ?>" max-length="30" min-lenght="4"/>
						<input class="form-control" type="submit" value="Modifier" name="btMailNum"  />
						</form>
					</div>
					<!-- Fin Partie Num et Mail -->

					<!-- Partie Mdp -->
					<?php 
					if(isset($_POST['btMdp'])){
						//Si le mdp est différent
						$newMdp = $_POST['newMdp'];
						if($_SESSION['mdp'] != $_POST['oldMdp']){
							$error[] = "Vous vous êtes trompez dans votre ancien mot de passe.";
						}
						elseif($_POST['newMdp'] != $_POST['newMdp2']){
							$warning[] = "Les 2 mots de passe ne sont pas identiques";
						}
						else {
							$query = "Update sos.utilisateur SET mdp = \"$newMdp\" where idutilisateur = '$_SESSION[idutilisateur]'";
							$conn->query($query);
							$succes[] = "Votre mot de passe à bien été changé";
						}
					}
					?>
					<div class="col-sm-4 col-xs-offset-1 col-xs-10">
						<h4><strong>Modification mot de passe :</strong></h4>
						<br/>
						<form action="formulairesMonCompte.php" method="post">
							<input class="form-control" type="password" name="oldMdp" placeholder="Ancien mot de passe." max-length="30" min-lenght="7"/>
							<input class="form-control" type="password" name="newMdp" placeholder="Nouveau mot de passe." max-length="30" min-lenght="7"/>
							<input class="form-control" type="password" name="newMdp2" placeholder="Vérification nouveau mot de passe." max-length="30" min-lenght="7"/>
							<input class="form-control" type="submit" value="Valider" name="btMdp"/>
						</form>
					</div>
					<!-- End Content -->
					<!-- Succes et Error -->
					<div class="row">
						<div class="col-xs-offset-2 col-xs-8">
							<br><br>
							<?php 
							if(count($succes) > 0){
						        foreach( $succes as $s )  
					            {  
					                echo( "<div class='alert alert-success' role='alert'>$s</div>" );  
					            }
					       	}
					       	if(count($warning) > 0){
						        foreach( $warning as $s )  
					            {  
					                echo( "<div class='alert alert-warning' role='alert'>$s</div>" );  
					            }
					       	}
							if(count($error) > 0){
						        foreach( $error as $s )  
					            {  
					                echo( "<div class='alert alert-danger' role='alert'>$s</div>" );  
					            }
					       	}
						    ?>						
						</div>
					</div>
					<!-- End affichage succes et Error -->
				</div>
			</div>
		</div>
	<?php include('universalFooter.php') ?>